@extends('admin.layout.app')

@section('content')
    <h4 href"marquee">bukan admin</h4>
@endsection