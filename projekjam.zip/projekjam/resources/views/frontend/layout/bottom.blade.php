  <!-- footer section -->
  <section class="container-fluid footer_section">
    <p>
      © 2020 All Rights Reserved By
      <a href="https://html.design/">Free Html Templates</a>
    </p>
  </section>
  <!-- footer section -->

  <script type="text/javascript" src="{{ asset('frontend/js/jquery-3.4.1.min.js') }}"></script>
  <script type="text/javascript" src="{{ asset('frontend/js/bootstrap.js') }}"></script>
</body>

</html>