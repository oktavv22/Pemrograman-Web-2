

<?php $__env->startSection('content'); ?>
<br>
<div class="d-flex justify-content-center">
    <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form method="POST" action="<?php echo e(url('admin/pelanggan/update/'. $prod->id)); ?>" class="col-sm-6">
        <?php echo e(csrf_field()); ?>

        <h4 style="text-align: center">Form Edit Data</h4>
        <div class="form-group row">
            <label for="nama" class="col-4 col-form-label">Nama</label>
            <div class="col-8">
                <input id="nama" name="nama" type="text" value="<?php echo e($prod->nama); ?>" class="form-control" spellcheck="false" data-ms-editor="true">
            </div>
        </div>
        <div class="form-group row">
            <label for="alamat" class="col-4 col-form-label">Alamat</label>
            <div class="col-8">
                <input id="alamat" name="alamat" type="text" value="<?php echo e($prod->alamat); ?>" class="form-control" spellcheck="false" data-ms-editor="true">
            </div>
        </div>
        <div class="form-group row">
            <label for="no_hp" class="col-4 col-form-label">No Hp</label>
            <div class="col-8">
                <input id="no_hp" name="no_hp" type="text" value="<?php echo e($prod->no_hp); ?>" class="form-control" spellcheck="false" data-ms-editor="true">
            </div>
        </div>
        <div class="form-group row">
            <div class="offset-4 col-8">
                <button name="submit" type="submit" class="btn btn-danger">Simpan Edit</button>
            </div>
        </div>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectjam\projekjam\resources\views/admin/pelanggan/edit.blade.php ENDPATH**/ ?>