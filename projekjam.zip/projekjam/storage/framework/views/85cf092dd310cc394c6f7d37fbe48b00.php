
<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->role !='pelanggan'): ?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Tables</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Tables</li>
    </ol>
    <div class="card mb-4 bg-primary text-white">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-table me-2"></i>Data Pelanggan</h5>
            <?php if(Auth::user()->role == 'admin'): ?>
            <a href="<?php echo e(url('admin/pelanggan/create')); ?>" class="btn btn-danger">Tambah Data</a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped text-white" id="datatablesSimple" width="100%" cellspacing="0">
                    <thead> 

                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Alamat</th>
                            <th>No Hp</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        ?>
                        <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no); ?></td>
                            <td><?php echo e($prod->nama); ?></td>
                            <td><?php echo e($prod->alamat); ?></td>
                            <td><?php echo e($prod->no_hp); ?></td>
                            <td>
                                <a href="<?php echo e(url ('admin/pelanggan/edit/'. $prod->id)); ?>" class="btn btn-sm btn-success">Edit</a>
                                <a href="<?php echo e(url ('admin/pelanggan/delete/'. $prod->id)); ?>" class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php
                        $no++
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php else: ?>
<?php echo $__env->make('admin.acces_denied', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prakweb2\LARAVEL\projekjam\resources\views/admin/pelanggan/pelanggan.blade.php ENDPATH**/ ?>