<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
  <!-- Basic page needs -->
  <meta charset="utf-8">
  <title>Welcome - Demo</title>
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Mobile specific metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- CSS -->
  <link rel="stylesheet" href="welcome/css/base.css">
  <link rel="stylesheet" href="welcome/css/demo.css">

  <!-- Favicons -->
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
  <link rel="icon" href="favicon.ico" type="image/x-icon">

</head>

<body>
  <!-- Header -->
  <header>
    <div class="row">
      <div class="col-twelve">
        <h1>Welcome<span>.</span></h1>
        <p class="lead">
          Selamat Datang di website toko jam kelompok 4
        </p>
      </div>
    </div>
  </header>

  <!-- Main Content -->
  <main>
    <div class="row">
      <div class="block-1-3 block-m-1-2 block-tab-full">
        <div class="col-block entry">
          
        </div>

        <div class="col-block entry">
          
        </div>

        <div class="col-block entry">
          
        </div>
      </div>
    </div>

    <!-- Login and Registration Buttons -->
    <div class="card" >
        <div class="card-body">
          <div class="row">
            <div class="col-twelve">
              <div class="button-group">
                <a class="button button-primary" href="<?php echo e(route('login')); ?>" style="background-color: red; color: white; border-radius: 50px; padding: 10px 20px; text-decoration: none;">Login</a>
                <a class="button button-secondary" href="<?php echo e(route('register')); ?>" style="background-color: white; color: red; border-radius: 50px; padding: 10px 20px; text-decoration: none; border: 2px solid red;">Register</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      
  </main>

  <!-- Preloader -->
  <div id="preloader">
    <div id="loader">
      <div class="line-scale-pulse-out">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
      </div>
    </div>
  </div>

  <!-- JavaScript -->
  <script src="welcome/js/jquery-3.2.1.min.js"></script>
  <script src="welcome/js/plugins.js"></script>
  <script src="welcome/js/main.js"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\projectjam\projekjam\resources\views/welcome.blade.php ENDPATH**/ ?>