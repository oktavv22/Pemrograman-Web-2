
<?php $__env->startSection('content'); ?>


<div class="container-fluid px-4">
    <h1 class="mt-4">Tables</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">produk</li>
    </ol>
    <div class="card mb-4">
        <div class="card-header">
       
            <a href="<?php echo e(url ('admin/kategori/create')); ?>" class="btn btn-primary">Tambah Data</a>
            <i class="fas fa-table me-1"></i>
            
        </div>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Data produk
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Action</th>
                    </tr>
                </thead>               
                <tbody>
                <?php
                $no = 1;
                ?>
                <?php $__currentLoopData = $kategori_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($no); ?></th>
                        <th><?php echo e($kate->nama); ?></th>
                        <td><a href="<?php echo e(url ('admin/kategori/edit/'. $kate->id)); ?>" class="btn btn-success">Edit</a></td>
                        <td><a href="<?php echo e(url ('admin/kategori/delete/'. $kate->id)); ?>" class="btn btn-danger">Delete</a></td>
                    </tr>
                <?php
                $no++
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekjam\projekjam\resources\views/admin/kategori/kategori.blade.php ENDPATH**/ ?>