
<?php $__env->startSection('content'); ?>


<div class="container-fluid px-4">
    <h1 class="mt-4">Tables</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Pesanan</li>
    </ol>
    <div class="card mb-4">
        <div class="card-header">
        
        <a class="btn btn-primary" href="<?php echo e(url('admin/pesanan/create')); ?>">Tambah</a>
        
            <a href="<?php echo e(url ('admin/pesanan/create')); ?>" class="btn btn-primary">Tambah Data</a>
            <i class="fas fa-table me-1"></i>
            
        </div>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Data Pesanan
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>tanggal</th>
                        <th>nama_pemesan</th>
                        <th>alamat_pemesan</th>
                        <th>no_hp</th>
                        <th>email</th>
                        <th>jumlah_pesanan</th>
                        <th>Deskripsi</th>
                        <th>produk_id</th>
                    </tr>
                </thead>               
                <tbody>
                <?php
                $no = 1;
                ?>
                <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th><?php echo e($no); ?></th>
                        <th><?php echo e($pesan->tanggal); ?></th>
                        <th><?php echo e($pesan->nama_pemesan); ?></th>
                        <th><?php echo e($pesan->alamat_pemesan); ?></th>
                        <th><?php echo e($pesan->no_hp); ?></th>
                        <th><?php echo e($pesan->email); ?></th>
                        <th><?php echo e($pesan->jumlah_pesanan); ?></th>
                        <th><?php echo e($pesan->deskripsi); ?></th>
                        <th><?php echo e($pesan->produk_id); ?></th>
                        <td><a href="<?php echo e(url ('admin/pesanan/edit/'. $pesan->id)); ?>" class="btn btn-success">Edit</a></td>
                        <td><a href="<?php echo e(url ('admin/pesanan/delete/'. $pesan->id)); ?>" class="btn btn-danger">Delete</a></td>
                    </tr>
                <?php
                $no++
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projekjam\projekjam\resources\views/admin/pesanan/pesanan.blade.php ENDPATH**/ ?>