  <!-- footer section -->
  <section class="container-fluid footer_section">
    <p>
      © 2020 All Rights Reserved By
      <a href="https://html.design/">Free Html Templates</a>
    </p>
  </section>
  <!-- footer section -->

  <script type="text/javascript" src="<?php echo e(asset('frontend/js/jquery-3.4.1.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('frontend/js/bootstrap.js')); ?>"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\prakweb2\LARAVEL\projekjam\resources\views/frontend/layout/bottom.blade.php ENDPATH**/ ?>