<?php echo $__env->make('frontend.layout.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="hero_area">
  <header class="header_section" >
    <div class="container-fluid">
        <?php echo $__env->make('frontend.layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </header>

  <?php echo $__env->yieldContent('content'); ?>
           
<?php echo $__env->make('frontend.layout.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\prakweb2\LARAVEL\projekjam\resources\views/frontend/layout/app.blade.php ENDPATH**/ ?>